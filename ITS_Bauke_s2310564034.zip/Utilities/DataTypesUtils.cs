﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferSecure.Utilities
{
    internal class DataTypesUtils
    {
        public static string btos(bool value)
        {
            return value? "1":"0";
        }
    }
}
